import 'package:asset_tracker/ui/constants/theme_data.dart';
import 'package:asset_tracker/ui/utilities/routes.dart';
import 'package:asset_tracker/ui/widgets/custom_form_text_field.dart';
import 'package:asset_tracker/ui/widgets/pry_btn.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../ui/utilities/size_config.dart';

class Authentication extends StatefulWidget {
  const Authentication({Key? key}) : super(key: key);

  @override
  State<Authentication> createState() => _AuthenticationState();
}

class _AuthenticationState extends State<Authentication> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    double? defaultSize = SizeConfig.defaultSize!;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(defaultSize * 2),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: defaultSize * 30,
                  height: defaultSize * 20,
                  child: Image.asset("assets/logo/bcc.png"),
                ),
              ),
              SizedBox(height: defaultSize * 2,),
              Text(
                "Sign in to continue",
                style: TextStyle(
                  color: textColor,
                  fontSize: defaultSize * 1.8
                ),
              ),
              SizedBox(height: defaultSize * 2,),
              CustomFormTextWidget(hint: "Email", obscureText: false, keyboardType: TextInputType.emailAddress),
              CustomFormTextWidget(hint: "Password", obscureText: true, keyboardType: TextInputType.text),
              SizedBox(height: defaultSize * 2,),
              PrimaryButton(label: "Signin", onPressed: (){Get.offAndToNamed(GetRoutes.dashboard);}, icon: Icons.arrow_right_alt)
            ],
          ),
        ),
      ),
    );
  }
}
