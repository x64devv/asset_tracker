import 'package:asset_tracker/ui/constants/theme_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../ui/utilities/size_config.dart';

class CheckInOut extends StatefulWidget {
  const CheckInOut({Key? key}) : super(key: key);

  @override
  State<CheckInOut> createState() => _CheckInOutState();
}

class _CheckInOutState extends State<CheckInOut> {
  var items = ["Printer", "Laptop", "Desktop", "VoIp Phone", "Tablet"];
  var item = "Add";
  @override
  Widget build(BuildContext context) {
    double? defaultSize = SizeConfig.defaultSize!;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Get.back(),
            icon: Icon(
                Icons.arrow_back_outlined
            )
        ),
        title: Text(
            "Check In/Out"
        ),
        actions: [
          IconButton(
            onPressed: (){},
            icon: Icon(
              Icons.search
            ),
          )
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(defaultSize * 2),
          child: SingleChildScrollView(
            child: Column(
              children: [
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                      color: textColor,
                      fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                    "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: () => showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                  "Add",
                                style: TextStyle(
                                  color: bluishClr
                                ),
                              ),
                              PopupMenuButton<String>(
                                icon: Icon(
                                    Icons.arrow_drop_down,
                                  color: bluishClr,
                                ),
                                onSelected: (String value) {
                                  item = value;
                                  showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        title: Text(
                                          "Available"
                                        ),
                                        content: SizedBox(
                                          width: defaultSize * double.infinity,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              children: [
                                                ListTile(
                                                  title: TextButton(
                                                    onPressed: (){
                                                      Get.back();
                                                    },
                                                      child: Text(
                                                          "BCC_SN_758re56_23",
                                                        style: TextStyle(
                                                          color: textColor
                                                        ),
                                                      ),
                                                  ),
                                                ),
                                                Divider(
                                                  color: textColor.withOpacity(0.1),
                                                ),
                                                ListTile(
                                                  title: TextButton(
                                                    onPressed: (){
                                                      Get.back();
                                                    },
                                                      child: Text(
                                                          "BCC_SN_354ddty56_23",
                                                        style: TextStyle(
                                                          color: textColor
                                                        ),
                                                      )
                                                  ),
                                                ),
                                                Divider(
                                                  color: textColor.withOpacity(0.1),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      )
                                  );
                                },
                                itemBuilder: (BuildContext context) {
                                  return items.map<PopupMenuItem<String>>((String value) {
                                    return PopupMenuItem(child: new Text(value), value: value);
                                  }).toList();
                                },
                              )
                            ],
                          ),
                          content: SizedBox(
                            width: defaultSize * double.infinity,
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  Container(
                                    width: defaultSize * double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                                "Laptop",
                                              style: TextStyle(
                                                fontSize: defaultSize * 1.6
                                              ),
                                            ),
                                            Text(
                                              "3",
                                              style: TextStyle(
                                                color: textColor.withOpacity(0.7)
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.remove,
                                                color: Colors.redAccent,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.add,
                                                color: Colors.greenAccent,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: textColor.withOpacity(0.1),
                                  ),
                                  Container(
                                    width: defaultSize * double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Laptop",
                                              style: TextStyle(
                                                  fontSize: defaultSize * 1.6
                                              ),
                                            ),
                                            Text(
                                              "3",
                                              style: TextStyle(
                                                  color: textColor.withOpacity(0.7)
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.remove,
                                                color: Colors.redAccent,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.add,
                                                color: Colors.greenAccent,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: textColor.withOpacity(0.1),
                                  ),
                                  Container(
                                    width: defaultSize * double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Laptop",
                                              style: TextStyle(
                                                  fontSize: defaultSize * 1.6
                                              ),
                                            ),
                                            Text(
                                              "3",
                                              style: TextStyle(
                                                  color: textColor.withOpacity(0.7)
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.remove,
                                                color: Colors.redAccent,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.add,
                                                color: Colors.greenAccent,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: textColor.withOpacity(0.1),
                                  ),
                                  Container(
                                    width: defaultSize * double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Laptop",
                                              style: TextStyle(
                                                  fontSize: defaultSize * 1.6
                                              ),
                                            ),
                                            Text(
                                              "3",
                                              style: TextStyle(
                                                  color: textColor.withOpacity(0.7)
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.remove,
                                                color: Colors.redAccent,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.add,
                                                color: Colors.greenAccent,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: textColor.withOpacity(0.1),
                                  ),
                                  Container(
                                    width: defaultSize * double.infinity,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Laptop",
                                              style: TextStyle(
                                                  fontSize: defaultSize * 1.6
                                              ),
                                            ),
                                            Text(
                                              "3",
                                              style: TextStyle(
                                                  color: textColor.withOpacity(0.7)
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.remove,
                                                color: Colors.redAccent,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: (){},
                                              icon: Icon(
                                                Icons.add,
                                                color: Colors.greenAccent,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  Divider(
                                    color: textColor.withOpacity(0.1),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          actions: [
                            TextButton(
                                style: TextButton.styleFrom(
                                  backgroundColor: bluishClr,
                                  foregroundColor: Colors.white,
                                ),
                                onPressed: (){
                                    Get.back();
                                  },
                                child: Text("Save")
                            ),
                          ],
                        )
                    ),
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
                ListTile(
                  title: Text(
                    "User 1",
                    style: TextStyle(
                        color: textColor,
                        fontSize: defaultSize * 2
                    ),
                  ),
                  subtitle: Text(
                      "Laptop, VoIp Phone"
                  ),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(
                      Icons.edit,
                      color: bluishClr,
                    ),
                  ),
                ),
                Divider(
                  color: textColor.withOpacity(0.1),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
